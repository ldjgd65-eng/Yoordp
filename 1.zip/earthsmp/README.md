# Earth SMP — Flask Website

Premium nebula-themed Minecraft server site (HTML + CSS + Flask only, no JS frameworks).

## Quick start

```bash
python -m venv .venv
source .venv/bin/activate            # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

Open http://localhost:5000

## Admin panel

- URL: http://localhost:5000/admin/login
- Default login: **admin / admin123**
- Change the password right away from the *Change Password* page.

From the admin panel you can edit:
- Site settings (hero text, server IP, Discord link, map embed URL, footer, legal pages)
- Announcements
- Vote links + rewards
- Store products (name, description, price, category, featured)
- Wiki articles (guides, commands, rules, FAQs)
- Staff applications (review + delete)

## Logo

Replace `static/img/logo.png` with your own logo (square, transparent PNG works best).
It is automatically used in the navbar, hero, footer and favicon.

## Project structure

```
earthsmp/
├── app.py                  # Flask app + all routes
├── requirements.txt
├── instance/earthsmp.db    # SQLite (auto-created on first run)
├── static/
│   ├── css/style.css       # Nebula theme
│   └── img/logo.png        # Your logo
└── templates/
    ├── base.html           # Public layout (nav + footer)
    ├── home.html
    ├── vote.html
    ├── map.html
    ├── store.html
    ├── cart.html
    ├── wiki.html
    ├── staff_apply.html
    ├── legal.html          # /terms /privacy /refund /rules
    └── admin/
        ├── _layout.html
        ├── login.html
        ├── dashboard.html
        ├── settings.html
        ├── crud.html       # generic CRUD for products/votes/wiki/announcements
        ├── applications.html
        └── password.html
```

## Production notes

- Set a real `SECRET_KEY` env var: `export SECRET_KEY="something-long-random"`
- Run behind gunicorn: `gunicorn -w 2 -b 0.0.0.0:8000 app:app`
- The included store checkout is a stub — wire your own payment provider in `cart_checkout()` inside `app.py`.

Enjoy 🌌
