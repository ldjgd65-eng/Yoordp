import os, sqlite3
from functools import wraps
from datetime import datetime
from flask import (Flask, render_template, request, redirect, url_for,
                   session, flash, g, abort)
from werkzeug.security import generate_password_hash, check_password_hash

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
DB_PATH = os.path.join(BASE_DIR, "instance", "earthsmp.db")

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "change-me-please-very-long-secret")
os.makedirs(os.path.join(BASE_DIR, "instance"), exist_ok=True)

# --------------------------- DB helpers ---------------------------
def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db

@app.teardown_appcontext
def close_db(_=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()

SCHEMA = """
CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY, value TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS admins (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS announcements (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL, body TEXT NOT NULL,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS vote_links (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL, url TEXT NOT NULL, reward TEXT
);
CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL, description TEXT,
    price REAL NOT NULL DEFAULT 0,
    category TEXT NOT NULL, featured INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS wiki_articles (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    category TEXT NOT NULL, title TEXT NOT NULL, body TEXT NOT NULL,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS applications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    mc_username TEXT, age TEXT, discord TEXT, timezone TEXT,
    experience TEXT, punishments TEXT, availability TEXT, reason TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP, status TEXT DEFAULT 'pending'
);
CREATE TABLE IF NOT EXISTS cart (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id TEXT NOT NULL, product_id INTEGER NOT NULL,
    qty INTEGER NOT NULL DEFAULT 1,
    FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE CASCADE
);
"""

DEFAULT_SETTINGS = {
    "site_name": "Earth SMP",
    "hero_title": "Welcome to Earth SMP",
    "hero_subtitle": "A premium survival experience set across a 1:1000 scale Earth.",
    "server_ip": "play.earthsmp.net",
    "server_description": "Earth SMP is our flagship gamemode — claim land, build nations, trade and explore a fully replicated Earth map under a vast nebula sky.",
    "discord_link": "https://discord.gg/your-invite",
    "store_link": "/store",
    "vote_intro": "Vote daily to support the server and earn cosmic rewards.",
    "map_embed_url": "https://map.example.com",
    "map_enabled": "1",
    "stat_players": "1,240",
    "stat_uptime": "99.9%",
    "stat_age": "3 years",
    "footer_text": "© Earth SMP — not affiliated with Mojang or Microsoft.",
    "tos_text": "These are the default Terms of Service. Edit me from the admin panel.",
    "privacy_text": "Default Privacy Policy. Edit from the admin panel.",
    "refund_text": "Default Refund Policy. Edit from the admin panel.",
    "rules_text": "1. No cheating.\n2. Respect everyone.\n3. No griefing.",
}

def init_db():
    db = get_db()
    db.executescript(SCHEMA)
    for k, v in DEFAULT_SETTINGS.items():
        db.execute("INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)", (k, v))
    cur = db.execute("SELECT COUNT(*) c FROM admins").fetchone()
    if cur["c"] == 0:
        db.execute("INSERT INTO admins(username,password_hash) VALUES(?,?)",
                   ("admin", generate_password_hash("admin123")))
    if db.execute("SELECT COUNT(*) c FROM products").fetchone()["c"] == 0:
        seed = [
            ("Stellar Rank","Premium rank with cosmic perks",9.99,"Ranks",1),
            ("Galactic Rank","Top tier rank — full features",24.99,"Ranks",1),
            ("Nebula Crate","Random cosmic loot",4.99,"Crates",1),
            ("Star Key","Opens any crate",1.99,"Keys",0),
            ("1000 Coins","In-game currency",4.99,"Coins",0),
            ("Comet Trail","Particle cosmetic",3.49,"Cosmetics",1),
        ]
        db.executemany("INSERT INTO products(name,description,price,category,featured) VALUES(?,?,?,?,?)", seed)
    if db.execute("SELECT COUNT(*) c FROM vote_links").fetchone()["c"] == 0:
        db.executemany("INSERT INTO vote_links(name,url,reward) VALUES(?,?,?)", [
            ("PlanetMinecraft","https://example.com/vote1","1 Nebula Crate"),
            ("MinecraftServers","https://example.com/vote2","500 Coins"),
        ])
    if db.execute("SELECT COUNT(*) c FROM announcements").fetchone()["c"] == 0:
        db.execute("INSERT INTO announcements(title,body) VALUES(?,?)",
                   ("Season 2 Launch","Earth SMP Season 2 is live with new continents to claim!"))
    if db.execute("SELECT COUNT(*) c FROM wiki_articles").fetchone()["c"] == 0:
        db.executemany("INSERT INTO wiki_articles(category,title,body) VALUES(?,?,?)", [
            ("Guides","Getting Started","Join with the IP, pick a country, and /claim your land."),
            ("Commands","/claim","Claim a chunk of land for your nation."),
            ("Rules","No Griefing","Destroying others' builds outside war is forbidden."),
            ("FAQ","How do I join a nation?","Use /nation join <name> after being invited."),
        ])
    db.commit()

def get_settings():
    return {r["key"]: r["value"] for r in get_db().execute("SELECT key,value FROM settings")}

def set_setting(k, v):
    db = get_db()
    db.execute("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (k, v))
    db.commit()

@app.context_processor
def inject_globals():
    try:
        return {"settings": get_settings(), "now": datetime.utcnow()}
    except Exception:
        return {"settings": DEFAULT_SETTINGS, "now": datetime.utcnow()}

@app.before_request
def _ensure_db():
    if not os.path.exists(DB_PATH) or os.path.getsize(DB_PATH) == 0:
        init_db()

# --------------------------- Auth ---------------------------
def login_required(f):
    @wraps(f)
    def wrap(*a, **kw):
        if not session.get("admin"):
            return redirect(url_for("admin_login", next=request.path))
        return f(*a, **kw)
    return wrap

# --------------------------- Public routes ---------------------------
@app.route("/")
def home():
    db = get_db()
    announcements = db.execute("SELECT * FROM announcements ORDER BY id DESC LIMIT 3").fetchall()
    featured = db.execute("SELECT * FROM products WHERE featured=1 LIMIT 4").fetchall()
    wiki = db.execute("SELECT * FROM wiki_articles ORDER BY id DESC LIMIT 3").fetchall()
    votes = db.execute("SELECT * FROM vote_links LIMIT 3").fetchall()
    return render_template("home.html", announcements=announcements, featured=featured,
                           wiki=wiki, votes=votes)

@app.route("/vote")
def vote():
    votes = get_db().execute("SELECT * FROM vote_links").fetchall()
    return render_template("vote.html", votes=votes)

@app.route("/map")
def map_page():
    s = get_settings()
    return render_template("map.html", enabled=s.get("map_enabled")=="1", url=s.get("map_embed_url"))

@app.route("/store")
def store():
    cat = request.args.get("category","All")
    db = get_db()
    if cat == "All":
        products = db.execute("SELECT * FROM products ORDER BY category,id").fetchall()
    else:
        products = db.execute("SELECT * FROM products WHERE category=? ORDER BY id",(cat,)).fetchall()
    cats = ["All","Ranks","Crates","Keys","Coins","Cosmetics"]
    cart_count = db.execute("SELECT COALESCE(SUM(qty),0) c FROM cart WHERE session_id=?", (_sid(),)).fetchone()["c"]
    return render_template("store.html", products=products, categories=cats, current=cat, cart_count=cart_count)

def _sid():
    if "sid" not in session:
        session["sid"] = os.urandom(8).hex()
    return session["sid"]

@app.route("/cart/add/<int:pid>", methods=["POST"])
def cart_add(pid):
    db = get_db()
    row = db.execute("SELECT id FROM cart WHERE session_id=? AND product_id=?", (_sid(), pid)).fetchone()
    if row:
        db.execute("UPDATE cart SET qty=qty+1 WHERE id=?", (row["id"],))
    else:
        db.execute("INSERT INTO cart(session_id,product_id) VALUES(?,?)", (_sid(), pid))
    db.commit()
    return redirect(url_for("cart"))

@app.route("/cart")
def cart():
    rows = get_db().execute("""
        SELECT c.id, c.qty, p.name, p.price, p.category
        FROM cart c JOIN products p ON p.id=c.product_id
        WHERE c.session_id=?""", (_sid(),)).fetchall()
    total = sum(r["qty"]*r["price"] for r in rows)
    return render_template("cart.html", rows=rows, total=total)

@app.route("/cart/remove/<int:cid>", methods=["POST"])
def cart_remove(cid):
    db = get_db()
    db.execute("DELETE FROM cart WHERE id=? AND session_id=?", (cid, _sid()))
    db.commit()
    return redirect(url_for("cart"))

@app.route("/cart/checkout", methods=["POST"])
def cart_checkout():
    db = get_db()
    db.execute("DELETE FROM cart WHERE session_id=?", (_sid(),))
    db.commit()
    flash("Checkout simulated — connect your real payment provider in app.py.", "ok")
    return redirect(url_for("store"))

@app.route("/wiki")
def wiki():
    rows = get_db().execute("SELECT * FROM wiki_articles ORDER BY category,id").fetchall()
    grouped = {}
    for r in rows:
        grouped.setdefault(r["category"], []).append(r)
    return render_template("wiki.html", grouped=grouped)

@app.route("/staff-apply", methods=["GET","POST"])
def staff_apply():
    if request.method == "POST":
        f = request.form
        get_db().execute("""INSERT INTO applications
            (mc_username,age,discord,timezone,experience,punishments,availability,reason)
            VALUES(?,?,?,?,?,?,?,?)""",
            (f.get("mc_username","").strip()[:64], f.get("age","").strip()[:8],
             f.get("discord","").strip()[:64], f.get("timezone","").strip()[:32],
             f.get("experience","")[:2000], f.get("punishments","")[:1000],
             f.get("availability","")[:500], f.get("reason","")[:2000]))
        get_db().commit()
        flash("Application submitted. Good luck!", "ok")
        return redirect(url_for("staff_apply"))
    return render_template("staff_apply.html")

@app.route("/discord")
def discord_redirect():
    return redirect(get_settings().get("discord_link","#"))

@app.route("/terms")
def terms(): return render_template("legal.html", title="Terms of Service", body=get_settings().get("tos_text",""))
@app.route("/privacy")
def privacy(): return render_template("legal.html", title="Privacy Policy", body=get_settings().get("privacy_text",""))
@app.route("/refund")
def refund(): return render_template("legal.html", title="Refund Policy", body=get_settings().get("refund_text",""))
@app.route("/rules")
def rules(): return render_template("legal.html", title="Server Rules", body=get_settings().get("rules_text",""))

# --------------------------- Admin ---------------------------
@app.route("/admin/login", methods=["GET","POST"])
def admin_login():
    if request.method == "POST":
        u = request.form.get("username","").strip()
        p = request.form.get("password","")
        row = get_db().execute("SELECT * FROM admins WHERE username=?", (u,)).fetchone()
        if row and check_password_hash(row["password_hash"], p):
            session["admin"] = u
            return redirect(request.args.get("next") or url_for("admin_dashboard"))
        flash("Invalid credentials.", "err")
    return render_template("admin/login.html")

@app.route("/admin/logout")
def admin_logout():
    session.pop("admin", None)
    return redirect(url_for("admin_login"))

@app.route("/admin")
@login_required
def admin_dashboard():
    db = get_db()
    counts = {
        "products": db.execute("SELECT COUNT(*) c FROM products").fetchone()["c"],
        "applications": db.execute("SELECT COUNT(*) c FROM applications").fetchone()["c"],
        "wiki": db.execute("SELECT COUNT(*) c FROM wiki_articles").fetchone()["c"],
        "votes": db.execute("SELECT COUNT(*) c FROM vote_links").fetchone()["c"],
        "announcements": db.execute("SELECT COUNT(*) c FROM announcements").fetchone()["c"],
    }
    return render_template("admin/dashboard.html", counts=counts)

@app.route("/admin/settings", methods=["GET","POST"])
@login_required
def admin_settings():
    if request.method == "POST":
        for k in DEFAULT_SETTINGS.keys():
            if k in request.form:
                set_setting(k, request.form.get(k,""))
        flash("Settings saved.", "ok")
        return redirect(url_for("admin_settings"))
    return render_template("admin/settings.html", s=get_settings(), keys=list(DEFAULT_SETTINGS.keys()))

# Generic CRUD helpers
def _crud(table, fields, template, title, redirect_endpoint, order="id DESC"):
    db = get_db()
    action = request.form.get("_action") if request.method == "POST" else None
    if action == "create":
        cols = ",".join(fields); placeholders = ",".join(["?"]*len(fields))
        db.execute(f"INSERT INTO {table}({cols}) VALUES({placeholders})",
                   [request.form.get(f,"") for f in fields])
        db.commit(); flash("Created.","ok"); return redirect(url_for(redirect_endpoint))
    if action == "update":
        rid = request.form.get("id"); sets = ",".join([f"{f}=?" for f in fields])
        db.execute(f"UPDATE {table} SET {sets} WHERE id=?",
                   [*[request.form.get(f,"") for f in fields], rid])
        db.commit(); flash("Updated.","ok"); return redirect(url_for(redirect_endpoint))
    if action == "delete":
        db.execute(f"DELETE FROM {table} WHERE id=?", (request.form.get("id"),))
        db.commit(); flash("Deleted.","ok"); return redirect(url_for(redirect_endpoint))
    rows = db.execute(f"SELECT * FROM {table} ORDER BY {order}").fetchall()
    return render_template(template, rows=rows, title=title, fields=fields)

@app.route("/admin/announcements", methods=["GET","POST"])
@login_required
def admin_announcements():
    return _crud("announcements", ["title","body"], "admin/crud.html",
                 "Announcements", "admin_announcements")

@app.route("/admin/votes", methods=["GET","POST"])
@login_required
def admin_votes():
    return _crud("vote_links", ["name","url","reward"], "admin/crud.html",
                 "Vote Links", "admin_votes", order="id ASC")

@app.route("/admin/products", methods=["GET","POST"])
@login_required
def admin_products():
    return _crud("products", ["name","description","price","category","featured"],
                 "admin/crud.html", "Store Products", "admin_products", order="category,id")

@app.route("/admin/wiki", methods=["GET","POST"])
@login_required
def admin_wiki():
    return _crud("wiki_articles", ["category","title","body"], "admin/crud.html",
                 "Wiki Articles", "admin_wiki", order="category,id")

@app.route("/admin/applications")
@login_required
def admin_applications():
    rows = get_db().execute("SELECT * FROM applications ORDER BY id DESC").fetchall()
    return render_template("admin/applications.html", rows=rows)

@app.route("/admin/applications/<int:aid>/delete", methods=["POST"])
@login_required
def admin_app_delete(aid):
    get_db().execute("DELETE FROM applications WHERE id=?", (aid,))
    get_db().commit(); return redirect(url_for("admin_applications"))

@app.route("/admin/password", methods=["GET","POST"])
@login_required
def admin_password():
    if request.method == "POST":
        new = request.form.get("password","")
        if len(new) < 6:
            flash("Min 6 chars.", "err")
        else:
            get_db().execute("UPDATE admins SET password_hash=? WHERE username=?",
                             (generate_password_hash(new), session["admin"]))
            get_db().commit(); flash("Password changed.","ok")
        return redirect(url_for("admin_password"))
    return render_template("admin/password.html")

if __name__ == "__main__":
    with app.app_context():
        init_db()
    app.run(host="0.0.0.0", port=5000, debug=True)
