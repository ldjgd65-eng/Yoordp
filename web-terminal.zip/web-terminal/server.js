const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const pty = require('node-pty');
const path = require('path');
const basicAuth = require('express-basic-auth');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

const PORT = process.env.PORT || 3000;
const TERMINAL_USER = process.env.TERMINAL_USER || 'admin';
const TERMINAL_PASS = process.env.TERMINAL_PASS || 'admin123';

app.use(basicAuth({
  users: { [TERMINAL_USER]: TERMINAL_PASS },
  challenge: true,
  realm: 'Web Terminal'
}));

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.static(path.join(__dirname, 'public')));

app.get('/', (req, res) => {
  res.render('terminal');
});

io.on('connection', (socket) => {
  console.log('Client connected:', socket.id);

  const ptyProcess = pty.spawn('bash', [], {
    name: 'xterm-color',
    cols: 80,
    rows: 24,
    cwd: process.env.HOME || '/tmp',
    env: process.env
  });

  ptyProcess.onData((data) => {
    socket.emit('output', data);
  });

  socket.on('input', (data) => {
    ptyProcess.write(data);
  });

  socket.on('resize', ({ cols, rows }) => {
    try { ptyProcess.resize(cols, rows); } catch(e) {}
  });

  socket.on('disconnect', () => {
    console.log('Client disconnected:', socket.id);
    try { ptyProcess.kill(); } catch(e) {}
  });
});

server.listen(PORT, () => {
  console.log(`Web Terminal running on http://localhost:${PORT}`);
});
