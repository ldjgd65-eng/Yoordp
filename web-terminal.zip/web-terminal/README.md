# ⚡ Web Terminal

A browser-based terminal you can deploy on Render for free.
Built with Node.js, Express, EJS, Socket.IO and node-pty.

---

## 🚀 Deploy on Render

### Step 1 — Upload to GitHub
1. Create a new GitHub repository
2. Upload all these files to it

### Step 2 — Create Web Service on Render
Go to [render.com](https://render.com) → New → **Web Service** → Connect your GitHub repo

### Step 3 — Render Settings

| Setting | Value |
|---|---|
| **Environment** | Node |
| **Build Command** | `npm install` |
| **Start Command** | `node server.js` |

### Step 4 — Environment Variables
In Render → your service → **Environment** tab, add:

| Key | Value |
|---|---|
| `TERMINAL_USER` | `admin` (change this!) |
| `TERMINAL_PASS` | `yourpassword` (change this!) |

### Step 5 — Done!
Open your Render URL → enter your username & password → use the terminal!

---

## ⚠️ Important Notes
- Free Render tier **sleeps after 15 minutes** of inactivity (cold start ~30s)
- Change `TERMINAL_USER` and `TERMINAL_PASS` — **never use defaults in production**
- This gives full bash access — **only share with yourself**

## 🛠️ Local Development
```bash
npm install
node server.js
# Open http://localhost:3000
# Default login: admin / admin123
```
